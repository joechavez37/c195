**Please note: If for any reason a resolve file alert pops up, hit close and run the program.
**Fixed time issues that were displaying inaccurately between the dashboard and update controller.
**Please note: The times being populated in the update controller are in army-time so anything after 12
**Will look like 13 - 1:00
                 14 - 2:00
		 15 - 3:00
		 ..
		 ..
		 22 - 10:00
**So the times are accurate.

Title: Java Customer Appointment Application V.4

Purpose: The application's purpose is to provide a GUI-based scheduling solution for a global consulting organization. It will interface with an existing MySQL database, adhere to specified business requirements, and incorporate predefined data sources.

Author: Joseph Chavez, jcha306@wgu.edu, ID: 001307283

IDE: NetBeans 17
JDK Version: 17.0.1
JavaFX Version: 17.0.1
MySQL Connector driver version: mysql-connector-java-8.0.25

***Instructions for Application Usage:***

Initiation: Launch the application via **NetBeans**.

MySQL Connector: Within the project folders in NetBeans, find the libraries folder, right click and add jar, select the mysql-connector file that is
provided within the Virtual Machine.

Authentication: Provide the login credentials.

Appointment Alert: Upon successful login, an alert will appear, notifying you of any appointments scheduled within the forthcoming 15 minutes. If no appointments are within this timeframe, a message will indicate so. Please acknowledge and dismiss this alert to proceed.

Appointment Management:

Addition: Select the "Add Appointment" button to schedule a new appointment. Ensure all mandatory fields are populated.
Modification: To amend details of an existing appointment, select the desired appointment and subsequently click on "Update Appointment".
Deletion: To remove an appointment, select the desired appointment and choose the "Delete Appointment" button.

Customer Management:

Addition: To register a new customer, click on the "Add Customer" button. Populate all necessary fields. **Note: For the divisions list to be available, a country must first be chosen. Click "Save" to finalize the new customer addition.
Modification: For updating customer information, select the desired customer profile and then choose "Update Customer".
Deletion: To erase a customer record, select the particular customer and press the "Delete Customer" button.

Reports:

Access the reports section by selecting "Reports".
Within the reports interface, use the first dropdown menu to pick a specific User. This allows you to view either their "Contact Schedule" or "Customer Appointments" report.
For insights on customer distribution across divisions, select the "Generate Division-Customer Report" button.

Additional Report Explanation:
The "Division-Customer Report" integrated into this project provides a comprehensive overview of all divisions currently housing customers. Additionally, it details the aggregate number of customers within each division.
