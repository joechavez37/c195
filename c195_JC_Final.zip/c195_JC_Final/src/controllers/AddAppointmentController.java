// controllers/AddAppointmentController.java
package controllers;

import models.Appointment;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import utils.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import java.time.LocalTime;
import javafx.scene.control.ListCell;
import models.Customer;
import models.User;
import java.sql.SQLException;
import java.sql.ResultSet;
import javafx.scene.control.Alert;

public class AddAppointmentController {

    @FXML
    private TextField titleField, descriptionField, locationField, typeField, 
                      customerIDField, userIDField, contactIDField;
    @FXML
    private DatePicker startDatePicker, endDatePicker;
    @FXML
    private ComboBox<String> startHourComboBox, startMinuteComboBox, 
                             endHourComboBox, endMinuteComboBox;
    @FXML
    private ComboBox<User> userComboBox;
    @FXML
    private ComboBox<Customer> customerComboBox;
    @FXML
    private ComboBox<Contact> contactComboBox;
    @FXML
    private DashboardController dashboardController;

    public void setDashboardController(DashboardController dashboardController) {
        this.dashboardController = dashboardController;
    }
    
    /**
    * Initializes the UI components, particularly the ComboBoxes.
    * This method is called after the FXML file has been loaded.
    * It pre-populates the ComboBoxes with hour and minute values and sets up 
    * the display of customer names in the customer ComboBox.
    */
    @FXML
    private void initialize() {
        for (int i = 8; i <= 22; i++) {
            String hour = String.format("%02d", i);
            startHourComboBox.getItems().add(hour);
            endHourComboBox.getItems().add(hour);
        }
        for (int i = 0; i < 60; i += 15) {
            String minute = String.format("%02d", i);
            startMinuteComboBox.getItems().add(minute);
            endMinuteComboBox.getItems().add(minute);
        }
        
        customerComboBox.setCellFactory((comboBox) -> {
            return new ListCell<Customer>() {
                @Override
                protected void updateItem(Customer customer, boolean empty) {
                    super.updateItem(customer, empty);
                    if (customer == null || empty) {
                        setText(null);
                    } else {
                        setText(customer.getCustomerName());
                    }
                }
            };
        });

        customerComboBox.setButtonCell(new ListCell<Customer>() {
            @Override
            protected void updateItem(Customer customer, boolean empty) {
                super.updateItem(customer, empty);
                if (customer == null || empty) {
                    setText(null);
                } else {
                    setText(customer.getCustomerName());
                }
            }
        });
        
        contactComboBox.setCellFactory((comboBox) -> {
        return new ListCell<Contact>() {
            @Override
            protected void updateItem(Contact contact, boolean empty) {
                super.updateItem(contact, empty);
                if (contact == null || empty) {
                    setText(null);
                } else {
                    setText(contact.getContactName());
                }
            }
        };
    });

    contactComboBox.setButtonCell(new ListCell<Contact>() {
        @Override
        protected void updateItem(Contact contact, boolean empty) {
            super.updateItem(contact, empty);
            if (contact == null || empty) {
                setText(null);
            } else {
                setText(contact.getContactName());
            }
        }
    });

        populateUsers();
        populateCustomers();
        populateContacts();
    }
    
    /**
    * Populates the user ComboBox with users fetched from the database.
    * Sets up the display of user names in the ComboBox.
    */
    private void populateUsers() {
        String SQL = "SELECT * FROM users";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            ResultSet rs = (ResultSet) stmt.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setUserID(rs.getInt("User_ID"));
                user.setUserName(rs.getString("User_Name"));

                userComboBox.getItems().add(user);
            }

            userComboBox.setCellFactory((comboBox) -> {
                return new ListCell<User>() {
                    @Override
                    protected void updateItem(User user, boolean empty) {
                        super.updateItem(user, empty);
                        if (user == null || empty) {
                            setText(null);
                        } else {
                            setText(user.getUserName());
                        }
                    }
                };
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
    * Populates the customer ComboBox with customers fetched from the database.
    * It fetches details such as customerID, customerName, address, postalCode,
    * phone, createdBy, and divisionID. Sets up the display of customer names 
    * in the ComboBox.
    */
    private void populateCustomers() {
        String SQL = "SELECT * FROM customers";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            ResultSet rs = (ResultSet) stmt.executeQuery();

            while (rs.next()) {
                int customerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String address = rs.getString("Address");
                String postalCode = rs.getString("Postal_Code");
                String phone = rs.getString("Phone");
                String Created_By = rs.getString("Created_By");
                int divisionID = rs.getInt("Division_ID");

                Customer customer = new Customer(customerID, customerName, address, postalCode, phone, Created_By, divisionID);
                customerComboBox.getItems().add(customer);
            }

            customerComboBox.setCellFactory((comboBox) -> {
                return new ListCell<Customer>() {
                    @Override
                    protected void updateItem(Customer customer, boolean empty) {
                        super.updateItem(customer, empty);
                        if (customer == null || empty) {
                            setText(null);
                        } else {
                            setText(customer.getCustomerName());
                        }
                    }
                };
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static class Contact {
        private int contactId;
        private String contactName;

        public Contact(int contactId, String contactName) {
            this.contactId = contactId;
            this.contactName = contactName;
        }

        public int getContactId() {
            return contactId;
        }

        public String getContactName() {
            return contactName;
        }
    }
    
    private void populateContacts() {
        String SQL = "SELECT * FROM contacts";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int contactId = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");

                Contact contact = new Contact(contactId, contactName);
                contactComboBox.getItems().add(contact);
            }

            contactComboBox.setCellFactory((comboBox) -> {
                return new ListCell<Contact>() {
                    @Override
                    protected void updateItem(Contact contact, boolean empty) {
                        super.updateItem(contact, empty);
                        if (contact == null || empty) {
                            setText(null);
                        } else {
                            setText(contact.getContactName());
                        }
                    }
                };
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Checks if a proposed appointment time overlaps with any existing appointments in the database.
    * 
    * @param startDateTime Proposed start time for the appointment.
    * @param endDateTime Proposed end time for the appointment.
    * @return true if the proposed time overlaps with any existing appointment, false otherwise.
    */
    private boolean isAppointmentOverlap(LocalDateTime startDateTime, LocalDateTime endDateTime) {
        String SQL = "SELECT * FROM appointments WHERE " +
                     "(Start BETWEEN ? AND ? OR End BETWEEN ? AND ?) " +
                     "OR (Start <= ? AND End >= ?)";

        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);

            stmt.setTimestamp(1, java.sql.Timestamp.valueOf(startDateTime));
            stmt.setTimestamp(2, java.sql.Timestamp.valueOf(endDateTime));
            stmt.setTimestamp(3, java.sql.Timestamp.valueOf(startDateTime));
            stmt.setTimestamp(4, java.sql.Timestamp.valueOf(endDateTime));
            stmt.setTimestamp(5, java.sql.Timestamp.valueOf(startDateTime));
            stmt.setTimestamp(6, java.sql.Timestamp.valueOf(endDateTime));

            ResultSet rs = (ResultSet) stmt.executeQuery();

            // If there's any result, it means there's an overlap
            if (rs.next()) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
    * Displays an error alert with the specified title and message.
    * 
    * @param title The title of the error alert.
    * @param message The main message of the error alert.
    */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    /**
    * Validates the input fields to ensure they are not empty and contain valid data.
    * 
    * @return true if all input fields are valid, false otherwise.
    */
    private boolean validateInputFields() {
        if (titleField.getText().isEmpty()) {
            showAlert("Error", "Title field cannot be empty!");
            return false;
        }
        if (descriptionField.getText().isEmpty()) {
            showAlert("Error", "Description field cannot be empty!");
            return false;
        }
        if (locationField.getText().isEmpty()) {
            showAlert("Error", "Location field cannot be empty!");
            return false;
        }
        if (typeField.getText().isEmpty()) {
            showAlert("Error", "Type field cannot be empty!");
            return false;
        }
        if (startHourComboBox.getSelectionModel().isEmpty() || startMinuteComboBox.getSelectionModel().isEmpty()) {
            showAlert("Error", "Start Time must be selected!");
            return false;
        }
        if (endHourComboBox.getSelectionModel().isEmpty() || endMinuteComboBox.getSelectionModel().isEmpty()) {
            showAlert("Error", "End Time must be selected!");
            return false;
        }
        if (startDatePicker.getValue() == null) {
            showAlert("Error", "Start Date must be selected!");
            return false;
        }
        if (endDatePicker.getValue() == null) {
            showAlert("Error", "End Date must be selected!");
            return false;
        }
        if (userComboBox.getSelectionModel().isEmpty()) {
            showAlert("Error", "User must be selected!");
            return false;
        }
        if (customerComboBox.getSelectionModel().isEmpty()) {
            showAlert("Error", "Customer must be selected!");
            return false;
        }
        return true;
    }
    
    /**
    * Handles the action for the save button.
    * Validates input fields, checks for overlapping appointments, and saves the new appointment 
    * details to the database if everything is valid. If there's an error or overlap, an appropriate 
    * error message will be displayed.
    */
    @FXML
    private void handleSaveButtonAction() {
        if (!validateInputFields()) {
            return;
        }
        
        String startHour = startHourComboBox.getSelectionModel().getSelectedItem();
        String startMinute = startMinuteComboBox.getSelectionModel().getSelectedItem();
        LocalDateTime startDateTime = LocalDateTime.of(startDatePicker.getValue(), 
                                        LocalTime.of(Integer.parseInt(startHour), Integer.parseInt(startMinute)));

        String endHour = endHourComboBox.getSelectionModel().getSelectedItem();
        String endMinute = endMinuteComboBox.getSelectionModel().getSelectedItem();
        LocalDateTime endDateTime = LocalDateTime.of(endDatePicker.getValue(), 
                                        LocalTime.of(Integer.parseInt(endHour), Integer.parseInt(endMinute)));

        Customer selectedCustomer = customerComboBox.getSelectionModel().getSelectedItem();

        // Check for overlapping appointments
        if (isAppointmentOverlap(startDateTime, endDateTime)) {
            showAlert("Error", "The appointment overlaps with another appointment!");
            return;
        }
        
        Contact selectedContact = contactComboBox.getSelectionModel().getSelectedItem();
        if (selectedContact == null) {
            showAlert("Error", "Please select a contact!");
            return;
        }

        try {
            String SQL = "INSERT INTO appointments (Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);

            stmt.setString(1, titleField.getText());
            stmt.setString(2, descriptionField.getText());
            stmt.setString(3, locationField.getText());
            stmt.setString(4, typeField.getText());
            stmt.setTimestamp(5, java.sql.Timestamp.valueOf(startDateTime));
            stmt.setTimestamp(6, java.sql.Timestamp.valueOf(endDateTime));
            stmt.setInt(7, selectedCustomer.getCustomerID());
            User selectedUser = userComboBox.getSelectionModel().getSelectedItem();
            if (selectedUser == null) {
                // Handle the case where no user was selected.
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("No User Selected");
                alert.setContentText("Please select a user before saving.");
                alert.showAndWait();
                return;
            }
            int userId = selectedUser.getUserID();
            stmt.setInt(8, userId);
            stmt.setInt(9, selectedContact.getContactId()); 
            stmt.execute();
            
            if (dashboardController != null) {
            dashboardController.populateAppointmentsTable();
            }
            
            // Close the "Add Appointment" window
            Stage stage = (Stage) titleField.getScene().getWindow();
            stage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Handles the action for the cancel button.
    * Closes the current window.
    */
    @FXML
    private void handleCancelButtonAction() {
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }
}