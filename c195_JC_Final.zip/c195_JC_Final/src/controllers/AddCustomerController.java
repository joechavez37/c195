package controllers;

import models.User;
import models.Division;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import javafx.scene.control.Alert;
import javafx.scene.control.ListCell;

public class AddCustomerController {

    @FXML
    private TextField customerNameField, addressField, postalCodeField, phoneField;
    @FXML
    private ComboBox<Division> divisionIDComboBox;
    @FXML
    private ComboBox<User> userComboBox;
    private DashboardController dashboardController;
    public void setDashboardController(DashboardController dashboardController) {
        this.dashboardController = dashboardController;
    }
    @FXML
    private ComboBox<String> countryComboBox;
    
    /**
    * Initializes the form with default values, populates the users, and sets up listeners.
    * Specifically, the method sets up a listener for the country combo box to dynamically populate the divisions based on the selected country.
    */
    @FXML
    private void initialize() {
        populateUsers();
        countryComboBox.getItems().addAll("U.S.", "Canada", "U.K.");

        divisionIDComboBox.setPromptText("Select a Country first");

        countryComboBox.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                populateDivisions(newValue);
            } else {
                divisionIDComboBox.getItems().clear();
                divisionIDComboBox.setPromptText("Select a Country first");
            }
        });
    }

    /**
    * Retrieves and populates users from the database into the userComboBox.
    */
    private void populateUsers() {
        String SQL = "SELECT * FROM users";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            ResultSet rs = (ResultSet) stmt.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setUserID(rs.getInt("User_ID"));
                user.setUserName(rs.getString("User_Name"));

                userComboBox.getItems().add(user);
            }

            // Display the user's name in the ComboBox
            userComboBox.setCellFactory((comboBox) -> {
                return new ListCell<User>() {
                    @Override
                    protected void updateItem(User user, boolean empty) {
                        super.updateItem(user, empty);
                        if (user == null || empty) {
                            setText(null);
                        } else {
                            setText(user.getUserName());
                        }
                    }
                };
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Retrieves and populates divisions based on the selected country from the database into the divisionIDComboBox.
    * 
    * @param country The country based on which divisions are to be fetched.
    */
    private void populateDivisions(String country) {
        divisionIDComboBox.getItems().clear();

        int country_ID = 0;
        switch(country) {
            case "U.S.":
                country_ID = 1;
                break;
            case "Canada":
                country_ID = 3;
                break;
            case "U.K.":
                country_ID = 2;
                break;
        }

        String SQL = "SELECT * FROM first_level_divisions WHERE Country_ID = ?";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setInt(1, country_ID);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Division division = new Division();
                division.setDivisionID(rs.getInt("Division_ID"));
                division.setDivisionName(rs.getString("Division"));

                divisionIDComboBox.getItems().add(division);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Validates the input fields to ensure they are not empty and contain valid data.
    * 
    * @return true if all input fields are valid, false otherwise.
    */
    private boolean validateInputFields() {
        if (customerNameField.getText().isEmpty()) {
            showAlert("Error", "Customer Name field cannot be empty!");
            return false;
        }
        if (addressField.getText().isEmpty()) {
            showAlert("Error", "Address field cannot be empty!");
            return false;
        }
        if (postalCodeField.getText().isEmpty()) {
            showAlert("Error", "Postal Code field cannot be empty!");
            return false;
        }
        if (phoneField.getText().isEmpty()) {
            showAlert("Error", "Phone field cannot be empty!");
            return false;
        }
        if (userComboBox.getSelectionModel().getSelectedItem() == null) {
            showAlert("Error", "User must be selected!");
            return false;
        }
        if (countryComboBox.getSelectionModel().getSelectedItem() == null) {
            showAlert("Error", "Country must be selected!");
            return false;
        }
        if (divisionIDComboBox.getSelectionModel().getSelectedItem() == null) {
            showAlert("Error", "Division must be selected!");
            return false;
        }
        return true;
    }

    /**
    * Displays an error alert with the specified title and message.
    * 
    * @param title The title of the error alert.
    * @param message The main message of the error alert.
    */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    /**
    * Handles the action for the save button.
    * Validates input fields, and saves the new customer details to the database if everything is valid.
    * If there's an error, an appropriate error message will be displayed.
    */
    @FXML
    private void handleSaveButtonAction() {
        if (!validateInputFields()) {
            return;
        }
        
        try {
            String SQL = "INSERT INTO customers (Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);

            LocalDateTime now = LocalDateTime.now();

            stmt.setString(1, customerNameField.getText());
            stmt.setString(2, addressField.getText());
            stmt.setString(3, postalCodeField.getText());
            stmt.setString(4, phoneField.getText());
            stmt.setTimestamp(5, Timestamp.valueOf(now));
            stmt.setString(6, userComboBox.getSelectionModel().getSelectedItem().getUserName());
            stmt.setTimestamp(7, Timestamp.valueOf(now));
            stmt.setString(8, userComboBox.getSelectionModel().getSelectedItem().getUserName());
            stmt.setInt(9, divisionIDComboBox.getSelectionModel().getSelectedItem().getDivisionID());

            stmt.execute();
            
            if (dashboardController != null) {
            dashboardController.populateCustomersTable();
            }
            Stage stage = (Stage) customerNameField.getScene().getWindow();
            stage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Handles the action for the cancel button.
    * Closes the current window.
    */
    @FXML
    private void handleCancelButtonAction() {
        Stage stage = (Stage) customerNameField.getScene().getWindow();
        stage.close();
    }
}
