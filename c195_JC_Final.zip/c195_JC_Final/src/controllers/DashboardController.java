// controllers/DashboardController.java
package controllers;

import java.io.IOException;
import models.Appointment;
import models.Customer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import utils.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.Optional;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import models.User;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.function.UnaryOperator;
import javafx.beans.property.SimpleIntegerProperty; // <- Import for lambda to improve code
import javafx.beans.property.SimpleStringProperty; // <- Import for lambda to improve code
import javafx.scene.control.TableCell;
import utils.TimeUtil;
import java.sql.Timestamp;

public class DashboardController {

    @FXML
    private TableView<Appointment> appointmentsTable;

    @FXML
    private TableView<Customer> customersTable;
    
    @FXML
    private RadioButton weeklyRadio, monthlyRadio;

    @FXML
    private ToggleGroup filterToggleGroup;

    @FXML
    public void initialize() {
        populateAppointmentsTable();
        populateCustomersTable();
        filterToggleGroup = new ToggleGroup();
        weeklyRadio.setToggleGroup(filterToggleGroup);
        monthlyRadio.setToggleGroup(filterToggleGroup);
    }
    
    private User loggedInUser;

    public void setLoggedInUser(User user) {
        this.loggedInUser = user;
        checkUpcomingAppointments();
    }
    
    /**
    * Checks for any appointments for the logged-in user that will start within the next 15 minutes.
    * Notifies the user via an alert if there's an upcoming appointment or if there are no appointments.
    */
    @FXML
    public void checkUpcomingAppointments() {
        LocalDateTime now = LocalDateTime.now(ZoneOffset.UTC);
        LocalDateTime inFifteenMinutes = now.plusMinutes(15);

        try {
            Connection conn = DBConnection.getConnection();
            String SQL = "SELECT * FROM appointments WHERE User_ID = ? AND Start BETWEEN ? AND ?";
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setInt(1, loggedInUser.getUserID());
            stmt.setTimestamp(2, Timestamp.valueOf(now));
            stmt.setTimestamp(3, Timestamp.valueOf(inFifteenMinutes));

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Found an appointment within 15 minutes.");
                int appointmentId = rs.getInt("Appointment_ID");
                LocalDateTime appointmentTime = rs.getTimestamp("Start").toLocalDateTime();

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Upcoming Appointment");
                alert.setHeaderText("You have an upcoming appointment!");
                alert.setContentText(String.format("Appointment ID: %d at %s", appointmentId, appointmentTime.toString()));
                alert.showAndWait();
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("No Upcoming Appointments");
                alert.setHeaderText("You have no upcoming appointments in the next 15 minutes.");
                alert.showAndWait();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Handles the action when the filter button is pressed.
    * Filters the appointments table based on the radio button selection (weekly or monthly).
    */
    @FXML
    private void handleFilterButtonAction() {
        if(weeklyRadio.isSelected()) {
            populateAppointmentsTableWeekly();
        } else if(monthlyRadio.isSelected()) {
            populateAppointmentsTableMonthly();
        }
    }
    
    /**
    * Populates the appointments table with all appointments from the database.
    */
    void populateAppointmentsTable() {      
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm"); // For 12-hour format with AM/PM
        ZoneId userTimeZone = ZoneId.systemDefault();

        try {
            Connection conn = DBConnection.connection;
            Statement stmt = conn.createStatement();
            String SQL = "SELECT * FROM appointments";
            ResultSet rs = stmt.executeQuery(SQL);

            while(rs.next()) {

                LocalDateTime startUtc = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime endUtc = rs.getTimestamp("End").toLocalDateTime();

                // Convert UTC times to local time zone directly with LocalDateTime objects
                LocalDateTime startLocal = TimeUtil.convertUtcToLocal(rs.getTimestamp("Start").toLocalDateTime(), userTimeZone);
                LocalDateTime endLocal = TimeUtil.convertUtcToLocal(rs.getTimestamp("End").toLocalDateTime(), userTimeZone);

                Appointment appointment = new Appointment(
                    rs.getInt("Appointment_ID"),
                    rs.getString("Title"),
                    rs.getString("Description"),
                    rs.getString("Location"),
                    rs.getString("Type"),
                    rs.getTimestamp("Start").toLocalDateTime(),
                rs.getTimestamp("End").toLocalDateTime(),
                    rs.getInt("Customer_ID"),
                    rs.getInt("User_ID"),
                    rs.getInt("Contact_ID")
                );
                appointments.add(appointment);
            }

            // Setting up columns for the TableView
            appointmentsTable.getColumns().clear(); // Clear existing columns

            TableColumn<Appointment, Integer> idCol = new TableColumn<>("Appointment ID");
            idCol.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject()); // <- Lambda to improve code

            TableColumn<Appointment, String> titleCol = new TableColumn<>("Title");
            titleCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getTitle())); // <- Lambda to improve code

            TableColumn<Appointment, String> descCol = new TableColumn<>("Description");
            descCol.setCellValueFactory(new PropertyValueFactory<>("description"));

            TableColumn<Appointment, String> locCol = new TableColumn<>("Location");
            locCol.setCellValueFactory(new PropertyValueFactory<>("location"));

            TableColumn<Appointment, String> typeCol = new TableColumn<>("Type");
            typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));

            TableColumn<Appointment, String> startCol = new TableColumn<>("Start");
            startCol.setCellValueFactory(cellData -> {
                LocalDateTime start = cellData.getValue().getStart();
                LocalDateTime localStart = TimeUtil.convertUtcToLocal(start, ZoneId.systemDefault()); // Convert UTC to local time
                String formattedTime = localStart.format(timeFormatter); // Format the local time
                return new SimpleStringProperty(formattedTime);
            });

            TableColumn<Appointment, String> endCol = new TableColumn<>("End");
            endCol.setCellValueFactory(cellData -> {
                LocalDateTime end = cellData.getValue().getEnd();
                LocalDateTime localEnd = TimeUtil.convertUtcToLocal(end, ZoneId.systemDefault()); // Convert UTC to local time
                String formattedTime = localEnd.format(timeFormatter); // Format the local time
                return new SimpleStringProperty(formattedTime);
            });

            TableColumn<Appointment, Integer> customerIdCol = new TableColumn<>("Customer ID");
            customerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));

            TableColumn<Appointment, Integer> userIdCol = new TableColumn<>("User ID");
            userIdCol.setCellValueFactory(new PropertyValueFactory<>("userID"));

            TableColumn<Appointment, Integer> contactIdCol = new TableColumn<>("Contact ID");
            contactIdCol.setCellValueFactory(new PropertyValueFactory<>("contactID"));

            // Adding columns to the TableView
            appointmentsTable.getColumns().addAll(idCol, titleCol, descCol, locCol, typeCol, 
                                                  startCol, endCol, customerIdCol, userIdCol, contactIdCol);

            appointmentsTable.setItems(appointments);
            } catch (Exception e) {
                e.printStackTrace();
            }
            appointmentsTable.refresh();
    }
    
    /**
    * Transforms the 'Type' using a lambda expression to return an uppercase version appended with " - PROCESSED".
    * @param type The original type string.
    * @return The transformed type string.
    */
    private String processType(String type) {
        UnaryOperator<String> transformType = t -> t.toUpperCase() + " - PROCESSED";
        return transformType.apply(type);
    }

    /**
    * Populates the appointments table with appointments for the current week.
    * The week starts on Monday and ends on Sunday.
    */
    void populateAppointmentsTableWeekly() {
        ObservableList<Appointment> weeklyAppointments = FXCollections.observableArrayList();
        LocalDate now = LocalDate.now();
        LocalDate startOfWeek = now.minusDays(now.getDayOfWeek().getValue() - 1); // Start from Monday
        LocalDate endOfWeek = startOfWeek.plusDays(6); // End on Sunday

        try {
            Connection conn = DBConnection.connection;
            String SQL = "SELECT * FROM appointments WHERE Start >= ? AND Start <= ?";
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setTimestamp(1, java.sql.Timestamp.valueOf(startOfWeek.atStartOfDay()));
            stmt.setTimestamp(2, java.sql.Timestamp.valueOf(endOfWeek.atTime(23, 59, 59)));

            ResultSet rs = stmt.executeQuery();
            while(rs.next()) {
            /** 
            * New lambda expression to process the 'Type' data.
            * This lambda improves code maintainability by centralizing type processing.
            */
            String processedType = processType(rs.getString("Type"));
            Appointment appointment = new Appointment(
                rs.getInt("Appointment_ID"),
                rs.getString("Title"),
                rs.getString("Description"),
                rs.getString("Location"),
                processedType,
                rs.getTimestamp("Start").toLocalDateTime(),
                rs.getTimestamp("End").toLocalDateTime(),
                rs.getInt("Customer_ID"),
                rs.getInt("User_ID"),
                rs.getInt("Contact_ID")
            );
            weeklyAppointments.add(appointment);
        }

            appointmentsTable.setItems(weeklyAppointments);
        } catch (Exception e) {
            e.printStackTrace();
        }
        appointmentsTable.refresh();
    }
    
    /**
    * Populates the appointments table with appointments for the current month.
    */
    void populateAppointmentsTableMonthly() {
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();

        // Calculate start and end of the current month
        LocalDate today = LocalDate.now();
        LocalDate startOfMonth = today.withDayOfMonth(1);
        LocalDate endOfMonth = today.withDayOfMonth(today.lengthOfMonth());

        try {
            Connection conn = DBConnection.connection;
            String SQL = "SELECT * FROM appointments WHERE Start >= ? AND Start <= ?";
            PreparedStatement stmt = conn.prepareStatement(SQL);

            stmt.setTimestamp(1, java.sql.Timestamp.valueOf(startOfMonth.atStartOfDay()));
            stmt.setTimestamp(2, java.sql.Timestamp.valueOf(endOfMonth.atTime(23, 59, 59)));

            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                /** 
                * New lambda expression to process the 'Type' data.
                * This lambda improves code maintainability by centralizing type processing.
                */
                String processedType = processType(rs.getString("Type"));
                Appointment appointment = new Appointment(
                    rs.getInt("Appointment_ID"),
                    rs.getString("Title"),
                    rs.getString("Description"),
                    rs.getString("Location"),
                    processedType,
                    rs.getTimestamp("Start").toLocalDateTime(),
                    rs.getTimestamp("End").toLocalDateTime(),
                    rs.getInt("Customer_ID"),
                    rs.getInt("User_ID"),
                    rs.getInt("Contact_ID")
                );
                appointments.add(appointment);
            }

            appointmentsTable.setItems(appointments);
        } catch (Exception e) {
            e.printStackTrace();
        }
        appointmentsTable.refresh();
    }

    /**
    * Populates the customers table with all customers from the database.
    */
    public void populateCustomersTable() {
        ObservableList<Customer> customers = FXCollections.observableArrayList();

        try {
            Connection conn = DBConnection.connection;
            Statement stmt = conn.createStatement();
            String SQL = "SELECT * FROM customers";
            ResultSet rs = stmt.executeQuery(SQL);

            while(rs.next()) {
                Customer customer = new Customer(
                    rs.getInt("Customer_ID"),
                    rs.getString("Customer_Name"),
                    rs.getString("Address"),
                    rs.getString("Postal_Code"),
                    rs.getString("Phone"),
                    rs.getString("Created_By"),    
                    rs.getInt("Division_ID")
                );
                customers.add(customer);
            }

            // Setting up columns for the TableView
            customersTable.getColumns().clear(); // Clear existing columns

            TableColumn<Customer, Integer> idCol = new TableColumn<>("Customer ID");
            idCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));

            TableColumn<Customer, String> nameCol = new TableColumn<>("Customer Name");
            nameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));

            TableColumn<Customer, String> addressCol = new TableColumn<>("Address");
            addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));

            TableColumn<Customer, String> postalCodeCol = new TableColumn<>("Postal Code");
            postalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));

            TableColumn<Customer, String> phoneCol = new TableColumn<>("Phone");
            phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));

            TableColumn<Customer, Integer> divisionIdCol = new TableColumn<>("Division ID");
            divisionIdCol.setCellValueFactory(new PropertyValueFactory<>("divisionID"));

            // Adding columns to the TableView
            customersTable.getColumns().addAll(idCol, nameCol, addressCol, postalCodeCol, 
                                               phoneCol, divisionIdCol);

            customersTable.setItems(customers);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Handles the action when "Add Appointment" is selected.
    */
    @FXML
    private void handleAddAppointment() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/AddAppointment.fxml"));
            Parent addAppointmentRoot = fxmlLoader.load();
            AddAppointmentController controller = fxmlLoader.getController();
            controller.setDashboardController(this);
            Stage stage = new Stage();
            stage.setScene(new Scene(addAppointmentRoot));
            stage.setTitle("Add Appointment");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
    * Handles the action when "Update Appointment" is selected.
    */
    @FXML
    private void handleUpdateAppointment() {
        Appointment selectedAppointment = appointmentsTable.getSelectionModel().getSelectedItem();
        if (selectedAppointment != null) {
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getClassLoader().getResource("view/UpdateAppointment.fxml"));
                Parent updateAppointmentRoot = fxmlLoader.load();

                UpdateAppointmentController controller = fxmlLoader.getController();
                controller.initialize(selectedAppointment);
                
                controller.setOnAppointmentUpdateCallback(() -> {
                    populateAppointmentsTable(); // Refresh the appointments table
                });
                
                Stage stage = new Stage();
                stage.setScene(new Scene(updateAppointmentRoot));
                stage.setTitle("Update Appointment");
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Selection Error");
            alert.setHeaderText(null);
            alert.setContentText("Please select an appointment to update.");
            alert.showAndWait();
        }
    }
    
    public interface OnAppointmentUpdate {
        void onUpdate();
    }
    
    private OnAppointmentUpdate onAppointmentUpdateCallback;

    public void setOnAppointmentUpdateCallback(OnAppointmentUpdate callback) {
        this.onAppointmentUpdateCallback = callback;
    }

    
    /**
    * Handles the action when "Delete Appointment" is selected.
    */
    @FXML
    private void handleDeleteAppointment() {
        Appointment selectedAppointment = appointmentsTable.getSelectionModel().getSelectedItem();

        if (selectedAppointment != null) {
            // Show confirmation dialog
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Delete Appointment");
            alert.setHeaderText("Are you sure you want to delete the selected appointment?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                try {
                    String SQL = "DELETE FROM appointments WHERE Appointment_ID = ?";
                    Connection conn = DBConnection.getConnection();
                    PreparedStatement stmt = conn.prepareStatement(SQL);

                    stmt.setInt(1, selectedAppointment.getAppointmentID());

                    stmt.execute();

                    // Refresh appointments table after deleting
                    populateAppointmentsTable();
                } catch (Exception e) {
                    e.printStackTrace();
                    // Show error dialog to the user
                    Alert errorAlert = new Alert(AlertType.ERROR);
                    errorAlert.setHeaderText("Failed to delete appointment.");
                    errorAlert.showAndWait();
                }
            }
        } else {
            // Show dialog indicating that no appointment was selected for deletion.
            Alert infoAlert = new Alert(AlertType.INFORMATION);
            infoAlert.setHeaderText("Please select an appointment to delete.");
            infoAlert.showAndWait();
        }
    }
    
    /**
    * Handles the action when "Add Customer" is selected.
    */
    @FXML
    private void handleAddCustomer() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getClassLoader().getResource("view/AddCustomer.fxml"));
            Parent addCustomerRoot = fxmlLoader.load();

            AddCustomerController controller = fxmlLoader.getController();
            controller.setDashboardController(this);

            Stage stage = new Stage();
            stage.setScene(new Scene(addCustomerRoot));
            stage.setTitle("Add Customer");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
    * Handles the action when "Update Customer" is selected.
    */
    @FXML   
    private void handleUpdateCustomer() {
        try {
            Customer selectedCustomer = customersTable.getSelectionModel().getSelectedItem();

            // Check if a customer is selected
            if (selectedCustomer == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Selection Error");
                alert.setHeaderText(null);
                alert.setContentText("Please select a customer to update.");
                alert.showAndWait();
                return;
            }
            
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getClassLoader().getResource("view/UpdateCustomer.fxml"));
            Parent updateCustomerRoot = fxmlLoader.load();

            UpdateCustomerController controller = fxmlLoader.getController();
            controller.setDashboardController(this);
            controller.setCustomer(selectedCustomer);

            controller.setOnCustomerUpdateCallback(() -> {
                populateCustomersTable(); // Refresh the customers table
            }); 
            
            controller.setCustomer(selectedCustomer);

            Stage stage = new Stage();
            stage.setScene(new Scene(updateCustomerRoot));
            stage.setTitle("Update Customer");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
    * Handles the action when "Delete Customer" is selected.
    */
    @FXML
    private void handleDeleteCustomer() {
        Customer selectedCustomer = customersTable.getSelectionModel().getSelectedItem();
        if (selectedCustomer != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Customer");
            alert.setContentText("Are you sure you want to delete the selected customer?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                deleteCustomerFromDB(selectedCustomer);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Selection Error");
            alert.setHeaderText(null);
            alert.setContentText("Please select a customer to delete.");
            alert.showAndWait();
        }
    }
    
    /**
    * Deletes any existing appointments for a given customer.
    * 
    * @param customer The customer for which to delete associated appointments.
    */
    private void deleteAppointmentsForCustomer(Customer customer) {
        String SQL = "DELETE FROM appointments WHERE Customer_ID = ?";
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setInt(1, customer.getCustomerID());
            stmt.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Deletes a given customer from the database.
    * First, it will delete any appointments associated with the customer, 
    * and then delete the customer itself.
    *
    * @param customer The customer to be deleted.
    */
    private void deleteCustomerFromDB(Customer customer) {
        // First, delete all the appointments for the customer
        deleteAppointmentsForCustomer(customer);

        // Then delete the customer
        String SQL = "DELETE FROM customers WHERE Customer_ID = ?";
        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setInt(1, customer.getCustomerID());
            stmt.execute();
            if(weeklyRadio.isSelected()) {
                populateAppointmentsTableWeekly();
            } else if(monthlyRadio.isSelected()) {
                populateAppointmentsTableMonthly();
            } else {
                populateAppointmentsTable();
            }
            // Refresh the customer table
            populateCustomersTable();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Handles the action when "Reports" button is clicked.
    * Opens the report screen in a new window.
    */
    @FXML
    private void handleReportsButtonAction() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getClassLoader().getResource("view/ReportScreen.fxml"));
            Parent reportScreenRoot = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(reportScreenRoot));
            stage.setTitle("Reports");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
    * Handles the action when "Logout" button is clicked.
    * Closes the current dashboard window and opens the login screen.
    *
    * @param event The action event triggering the method.
    * @throws IOException If there is an issue loading the Login form FXML.
    */
    @FXML
    private void handleLogoutButtonAction(ActionEvent event) throws IOException {
        // Close the dashboard window and return to the login screen
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getClassLoader().getResource("view/LoginForm.fxml"));
            Parent dashboardRoot = fxmlLoader.load();
            stage.setScene(new Scene(dashboardRoot));
            stage.setTitle("Login");
            stage.show();
    }
}