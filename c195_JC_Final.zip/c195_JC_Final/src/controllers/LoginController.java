// controllers/LoginController.java
package controllers;

import models.User;
import utils.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.ZoneId;
import java.util.Locale;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import utils.Translation;
import utils.LoginActivityLogger;

public class LoginController {

    @FXML
    private TextField usernameField;
    
    @FXML
    private PasswordField passwordField;
    
    @FXML
    private Button loginButton;

    @FXML
    private Label loginStatusLabel;

    /**
    * Initializes the login form with default values.
    * Displays the user's location based on system ZoneId and sets the form language based on system locale.
    */
    @FXML
    public void initialize() {
        // Display the user's location (ZoneId)
        loginStatusLabel.setText("Location: " + ZoneId.systemDefault().toString());
        
        // Set form language based on system settings
        translateBasedOnLocale();
    }
    
    /**
    * Handles the action for the login button.
    * Authenticates the user's credentials and either opens the dashboard if successful or displays an error message.
    */
    @FXML
    private void handleLoginButtonAction() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        User loggedInUser = authenticate(username, password);

        boolean isLoginSuccessful = loggedInUser != null;  // Determine if login is successful

        // Log the activity
        LoginActivityLogger.logActivity(username, isLoginSuccessful);

        if (loggedInUser != null) {
            openDashboard(loggedInUser);
        } else {
            showError("LOGIN_ERROR");
        }
    }

    /**
    * Enum to represent various translations for UI elements and messages.
    * Contains key-value pairs for both English and French translations.
    */
    enum Translations {
        USERNAME_EN("Username"),
        USERNAME_FR("Nom d'utilisateur"),
        PASSWORD_EN("Password"),
        PASSWORD_FR("Mot de passe"),
        LOGIN_EN("Login"),
        LOGIN_FR("Connexion"),
        LOGIN_ERROR_EN("Invalid username or password!"),
        LOGIN_ERROR_FR("Nom d'utilisateur ou mot de passe invalide!");

        private final String text;

        Translations(String text) {
            this.text = text;
        }

        public String getText() {
            return text;
        }
    }
    
    /**
    * Authenticates the user using the provided username and password.
    *
    * @param username The username provided by the user.
    * @param password The password provided by the user.
    * @return A User object if the authentication is successful, null otherwise.
    */
    private User authenticate(String username, String password) {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            String SQL = "SELECT * FROM users WHERE User_Name='" + username + "' AND Password='" + password + "'";
            ResultSet rs = stmt.executeQuery(SQL);

            if (rs.next()) {
                User user = new User();
                user.setUserID(rs.getInt("User_ID"));
                return user;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
    * Checks if the system's default locale is French.
    *
    * @return true if the default locale is French, false otherwise.
    */
    private boolean isFrenchLocale() {
        return Locale.getDefault().getLanguage().equals("fr");
    }
    
    /**
    * Displays an error alert with the appropriate translation based on the system's locale.
    *
    * @param errorMessageKey The key to identify which error message translation to display.
    */
    private void showError(String errorMessageKey) {
        String errorMessage = isFrenchLocale() ? Translations.valueOf(errorMessageKey + "_FR").getText()
                                               : Translations.valueOf(errorMessageKey + "_EN").getText();
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(isFrenchLocale() ? "Erreur de connexion" : "Login Error");
        alert.setHeaderText(null);
        alert.setContentText(errorMessage);
        alert.showAndWait();
    }
    
    /**
     * Sets the translations for UI elements on the form based on the system's locale.
     */
    private void translateBasedOnLocale() {
        if (isFrenchLocale()) {
            usernameField.setPromptText(Translations.USERNAME_FR.getText());
            passwordField.setPromptText(Translations.PASSWORD_FR.getText());
            loginButton.setText(Translations.LOGIN_FR.getText());
        } else {
            usernameField.setPromptText(Translations.USERNAME_EN.getText());
            passwordField.setPromptText(Translations.PASSWORD_EN.getText());
            loginButton.setText(Translations.LOGIN_EN.getText());
        }
    }
    
    /**
    * Opens the dashboard window and sets the logged-in user.
    * The dashboard is loaded from an external FXML file.
    *
    * @param user The User object representing the authenticated and logged-in user.
    */
    private void openDashboard(User user) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/Dashboard.fxml"));
            Parent dashboardRoot = fxmlLoader.load();

            DashboardController controller = fxmlLoader.getController();
            controller.setLoggedInUser(user);

            Stage stage = new Stage();
            stage.setScene(new Scene(dashboardRoot));
            stage.setTitle("Dashboard");
            stage.show();

            Stage loginStage = (Stage) usernameField.getScene().getWindow();
            loginStage.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
