package controllers;

import com.mysql.cj.conf.IntegerProperty;
import com.mysql.cj.conf.StringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import models.Appointment;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.collections.ListChangeListener;

public class ReportScreenController {
    
    @FXML
    private ComboBox<String> contactComboBox;
    
    @FXML
    private TableView<AppointmentSummary> appointmentSummaryTable;
    @FXML
    private TableColumn<AppointmentSummary, Integer> monthColumn;
    @FXML
    private TableColumn<AppointmentSummary, String> typeColumn;
    @FXML
    private TableColumn<AppointmentSummary, Integer> totalColumn;
    @FXML
    private TableView<Appointment> contactScheduleTable;
    @FXML
    private TableColumn<Appointment, Integer> appointmentIdColumn;
    @FXML
    private TableColumn<Appointment, String> titleColumn;
    @FXML
    private TableColumn<Appointment, String> descriptionColumn;
    @FXML
    private TableColumn<Appointment, LocalDateTime> startColumn;
    @FXML
    private TableColumn<Appointment, LocalDateTime> endColumn;
    @FXML
    private TableColumn<Appointment, Integer> customerIdColumn;
    @FXML
    private void clearAppointmentSummaryTable() {
        appointmentSummaryTable.getItems().clear();
    }
    @FXML
    private void clearContactScheduleTable() {
        contactScheduleTable.getItems().clear();
    }
    @FXML
    private Button clearAppointmentSummaryButton;
    @FXML
    private Button clearContactScheduleButton;
    @FXML
    private TableView<DivisionSummary> divisionCustomerTable;
    @FXML
    private TableColumn<DivisionSummary, Integer> divisionColumn;
    @FXML
    private TableColumn<DivisionSummary, Integer> customerCountColumn;

    /**
    * Initializes the report viewer with default values.
    * Sets items for contactComboBox, configures table columns, and sets up button actions and listeners.
    */
    @FXML
    public void initialize() {
        contactComboBox.setItems(getContactNames());

        // Setting up columns for the first report
        monthColumn.setCellValueFactory(new PropertyValueFactory<>("month"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("total"));

        clearAppointmentSummaryButton.setOnAction(event -> clearAppointmentSummaryTable());
        clearContactScheduleButton.setOnAction(event -> clearContactScheduleTable());

        appointmentSummaryTable.getItems().addListener((ListChangeListener.Change<? extends AppointmentSummary> change) -> {
            clearAppointmentSummaryButton.setDisable(appointmentSummaryTable.getItems().isEmpty());
        });

        contactScheduleTable.getItems().addListener((ListChangeListener.Change<? extends Appointment> change) -> {
            clearContactScheduleButton.setDisable(contactScheduleTable.getItems().isEmpty());
        });
        
        divisionColumn.setCellValueFactory(new PropertyValueFactory<>("divisionId"));
        customerCountColumn.setCellValueFactory(new PropertyValueFactory<>("totalCustomers"));
    }
    
    /**
    * Generates the reports and updates the UI with the report data.
    */
    public void generateReports() {
        generateCustomerAppointmentsReport();
        generateContactScheduleReport();
    }
    
    /**
    * Represents a summary of appointments, including the month, type, and total count.
    */
    public class AppointmentSummary {
        private SimpleIntegerProperty month;
        private SimpleStringProperty type;
        private SimpleIntegerProperty total;

        public AppointmentSummary(int month, String type, int total) {
            this.month = new SimpleIntegerProperty(month);
            this.type = new SimpleStringProperty(type);
            this.total = new SimpleIntegerProperty(total);
        }

        public int getMonth() {
            return month.get();
        }

        public String getType() {
            return type.get();
        }

        public int getTotal() {
            return total.get();
        }

        public SimpleIntegerProperty monthProperty() {
            return month;
        }

        public SimpleStringProperty typeProperty() {
            return type;
        }

        public SimpleIntegerProperty totalProperty() {
            return total;
        }
    }
    
    /**
    * Generates a report showcasing the number of appointments for each type and month.
    * Updates the appointmentSummaryTable with the fetched data.
    */
    public void generateCustomerAppointmentsReport() {
        try {
            Connection conn = DBConnection.connection;
            String SQL = "SELECT MONTH(Start) as Month, Type, COUNT(*) as Total "
                       + "FROM appointments GROUP BY MONTH(Start), Type";
            PreparedStatement stmt = conn.prepareStatement(SQL);
            ResultSet rs = stmt.executeQuery();

            ObservableList<AppointmentSummary> data = FXCollections.observableArrayList();

            while(rs.next()) {
                int month = rs.getInt("Month");
                String type = rs.getString("Type");
                int total = rs.getInt("Total");
                data.add(new AppointmentSummary(month, type, total));
            }
            
            appointmentSummaryTable.setItems(data);
            
            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Fetches all contact IDs from the database.
    *
    * @return ObservableList containing all contact IDs.
    */
    public ObservableList<Integer> getAllContactIds() {
        ObservableList<Integer> contactIds = FXCollections.observableArrayList();
        try {
            Connection conn = DBConnection.connection;
            Statement stmt = conn.createStatement();
            String SQL = "SELECT Contact_ID FROM contacts";
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                contactIds.add(rs.getInt("Contact_ID"));
            }
            
            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return contactIds;
    }
    
    /**
    * Fetches all contact names from the database.
    *
    * @return ObservableList containing all contact names.
    */
    private ObservableList<String> getContactNames() {
        ObservableList<String> contactNames = FXCollections.observableArrayList();

        try {
            Connection conn = DBConnection.connection;
            Statement stmt = conn.createStatement();
            String SQL = "SELECT Contact_Name FROM contacts";
            ResultSet rs = stmt.executeQuery(SQL);

            while(rs.next()) {
                String contactName = rs.getString("Contact_Name");
                contactNames.add(contactName);
            }
            
            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return contactNames;
    }

    /**
    * Generates a report of appointments for a selected contact.
    * Updates the contactScheduleTable with the fetched data.
    */
    public void generateContactScheduleReport() {
        try {
            Connection conn = DBConnection.connection;
            String SQL = "SELECT Appointment_ID, Title, Type, Description, Start, End, Customer_ID "
                       + "FROM appointments WHERE Contact_ID = ? ORDER BY Start";
            PreparedStatement stmt = conn.prepareStatement(SQL);

            ObservableList<Appointment> data = FXCollections.observableArrayList();

            // Fetching appointments for the selected contact
            String selectedContactName = contactComboBox.getValue();
            int contactId = getContactIdByName(selectedContactName);
            stmt.setInt(1, contactId);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                int appointmentId = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String type = rs.getString("Type");
                String description = rs.getString("Description");
                LocalDateTime start = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime end = rs.getTimestamp("End").toLocalDateTime();
                int customerId = rs.getInt("Customer_ID");

                Appointment appointment = new Appointment(appointmentId, title, description, null, type, start, end, customerId, 0, contactId);
                data.add(appointment);
            }

            contactScheduleTable.setItems(data);

            appointmentIdColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
            titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
            typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
            descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
            startColumn.setCellValueFactory(new PropertyValueFactory<>("start"));
            endColumn.setCellValueFactory(new PropertyValueFactory<>("end"));
            customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerID"));

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
    * Fetches the contact ID associated with a given contact name.
    *
    * @param name The name of the contact.
    * @return The ID of the contact, or -1 if not found.
    */
    public int getContactIdByName(String name) {
        int contactId = -1;
        try {
            Connection conn = DBConnection.connection;
            String SQL = "SELECT Contact_ID FROM contacts WHERE Contact_Name = ?";
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();

            if(rs.next()) {
                contactId = rs.getInt("Contact_ID");
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return contactId;
    }
    
    /**
    * Represents a summary of divisions, including the division ID and total customer count.
    */
    public class DivisionSummary {
        private SimpleIntegerProperty Division_ID;
        private SimpleIntegerProperty totalCustomers;

        public DivisionSummary(int divisionId, int totalCustomers) {
            this.Division_ID = new SimpleIntegerProperty(divisionId);
            this.totalCustomers = new SimpleIntegerProperty(totalCustomers);
        }

        public int getDivisionId() {
            return Division_ID.get();
        }

        public int getTotalCustomers() {
            return totalCustomers.get();
        }

        public SimpleIntegerProperty divisionIdProperty() {
            return Division_ID;
        }

        public SimpleIntegerProperty totalCustomersProperty() {
            return totalCustomers;
        }
    }
    
    /**
    * Generates a report showcasing the total number of customers for each division.
    * Updates the divisionCustomerTable with the fetched data.
    */
    public void generateDivisionCustomerReport() {
        try {
            Connection conn = DBConnection.connection;
            String SQL = "SELECT Division_ID, COUNT(DISTINCT Customer_ID) as TotalCustomers "
                       + "FROM customers GROUP BY Division_ID";
            PreparedStatement stmt = conn.prepareStatement(SQL);
            ResultSet rs = stmt.executeQuery();

            ObservableList<DivisionSummary> data = FXCollections.observableArrayList();

            while(rs.next()) {
                int divisionId = rs.getInt("Division_ID");
                int totalCustomers = rs.getInt("TotalCustomers");
                data.add(new DivisionSummary(divisionId, totalCustomers));
            }

            divisionCustomerTable.setItems(data);

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}