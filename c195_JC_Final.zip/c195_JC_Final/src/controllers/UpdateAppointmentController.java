// controllers/UpdateAppointmentController.java
package controllers;

import models.Appointment;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import utils.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.*;
import java.time.ZonedDateTime;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.scene.Node;

public class UpdateAppointmentController {

    private Appointment selectedAppointment;

    @FXML
    private TextField titleField, descriptionField, locationField, typeField,
            customerIDField, userIDField, contactIDField;
    @FXML
    private DatePicker startDatePicker, endDatePicker;
    @FXML
    private ComboBox<String> startHourComboBox, startMinuteComboBox,
            endHourComboBox, endMinuteComboBox;
    @FXML
    private ComboBox<Integer> customerIDComboBox;
    @FXML
    private ComboBox<Integer> userIDComboBox;
    @FXML
    private ComboBox<Integer> contactIDComboBox;
    
    /**
    * Initializes the UI components using data from the given appointment.
    * @param appointment The appointment data to preload.
    */
    public void initialize(Appointment appointment) {  
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now());
        this.selectedAppointment = appointment;
        preloadData();
    }
    
    /**
     * Pre-loads the time ComboBoxes with relevant values.
     */
    private void preloadComboBoxes() {
        startHourComboBox.getItems().clear();
        startMinuteComboBox.getItems().clear();
        endHourComboBox.getItems().clear();
        endMinuteComboBox.getItems().clear();

        for (int i = 8; i <= 22; i++) {
            String hour = String.format("%02d", i);
            startHourComboBox.getItems().add(hour);
            endHourComboBox.getItems().add(hour);
        }
        for (int i = 0; i < 60; i += 15) {
            String minute = String.format("%02d", i);
            startMinuteComboBox.getItems().add(minute);
            endMinuteComboBox.getItems().add(minute);
        }
    }
    
    /**
    * Preloads the UI components using data from the selected appointment.
    */
    private void preloadData() {

        preloadComboBoxes();

        titleField.setText(selectedAppointment.getTitle());
        descriptionField.setText(selectedAppointment.getDescription());
        locationField.setText(selectedAppointment.getLocation());
        typeField.setText(selectedAppointment.getType());
        customerIDField.setText(String.valueOf(selectedAppointment.getCustomerID()));
        userIDField.setText(String.valueOf(selectedAppointment.getUserID()));
        contactIDField.setText(String.valueOf(selectedAppointment.getContactID()));

        // Convert the UTC start and end times to the local time zone
        ZonedDateTime startZonedUTC = selectedAppointment.getStart().atZone(ZoneId.of("UTC"));
        ZonedDateTime endZonedUTC = selectedAppointment.getEnd().atZone(ZoneId.of("UTC"));
        ZonedDateTime startLocal = startZonedUTC.withZoneSameInstant(ZoneId.systemDefault());
        ZonedDateTime endLocal = endZonedUTC.withZoneSameInstant(ZoneId.systemDefault());

        startDatePicker.setValue(startLocal.toLocalDate());
        endDatePicker.setValue(endLocal.toLocalDate());

        // Adjust selection in combo boxes to match the local time
        selectComboBoxValue(startHourComboBox, startLocal.getHour());
        selectComboBoxValue(startMinuteComboBox, startLocal.getMinute());
        selectComboBoxValue(endHourComboBox, endLocal.getHour());
        selectComboBoxValue(endMinuteComboBox, endLocal.getMinute());
    }

    private void selectComboBoxValue(ComboBox<String> comboBox, int value) {
        String formatted = String.format("%02d", value);
        comboBox.getSelectionModel().select(formatted);
    }

    /**
    * Handles the save button action, which updates the selected appointment's data.
    * @param event The event that triggered this method.
    */
    @FXML
    public void handleSaveButtonAction(ActionEvent event) {
        try {
            LocalDate startDate = startDatePicker.getValue();
            String startHour = startHourComboBox.getSelectionModel().getSelectedItem();
            String startMinute = startMinuteComboBox.getSelectionModel().getSelectedItem();
            LocalTime startTime = LocalTime.of(Integer.parseInt(startHour), Integer.parseInt(startMinute));

            LocalDate endDate = endDatePicker.getValue();
            String endHour = endHourComboBox.getSelectionModel().getSelectedItem();
            String endMinute = endMinuteComboBox.getSelectionModel().getSelectedItem();
            LocalTime endTime = LocalTime.of(Integer.parseInt(endHour), Integer.parseInt(endMinute));

            // Convert local date and time to LocalDateTime
            LocalDateTime localStartDateTime = LocalDateTime.of(startDatePicker.getValue(), startTime);
            LocalDateTime localEndDateTime = LocalDateTime.of(endDatePicker.getValue(), endTime);

            // Convert LocalDateTime to ZonedDateTime in the user's local time zone, then to UTC
            ZonedDateTime utcStartDateTime = ZonedDateTime.of(localStartDateTime, ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));
            ZonedDateTime utcEndDateTime = ZonedDateTime.of(localEndDateTime, ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));

            // Update the selected appointment object
            selectedAppointment.setTitle(titleField.getText());
            selectedAppointment.setDescription(descriptionField.getText());
            selectedAppointment.setLocation(locationField.getText());
            selectedAppointment.setType(typeField.getText());
            selectedAppointment.setStart(utcStartDateTime.toLocalDateTime());
            selectedAppointment.setEnd(utcEndDateTime.toLocalDateTime());
            selectedAppointment.setCustomerID(Integer.parseInt(customerIDField.getText()));
            selectedAppointment.setUserID(Integer.parseInt(userIDField.getText()));
            selectedAppointment.setContactID(Integer.parseInt(contactIDField.getText()));

            // Update the appointment in the database
            try (Connection conn = DBConnection.connection) {
                String sql = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";

                try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                    preparedStatement.setString(1, selectedAppointment.getTitle());
                    preparedStatement.setString(2, selectedAppointment.getDescription());
                    preparedStatement.setString(3, selectedAppointment.getLocation());
                    preparedStatement.setString(4, selectedAppointment.getType());
                    preparedStatement.setTimestamp(5, Timestamp.valueOf(utcStartDateTime.toLocalDateTime()));
                    preparedStatement.setTimestamp(6, Timestamp.valueOf(utcEndDateTime.toLocalDateTime()));
                    preparedStatement.setInt(7, selectedAppointment.getCustomerID());
                    preparedStatement.setInt(8, selectedAppointment.getUserID());
                    preparedStatement.setInt(9, selectedAppointment.getContactID());
                    preparedStatement.setInt(10, selectedAppointment.getAppointmentID());

                    int result = preparedStatement.executeUpdate();
                    if (result > 0) {
                        showAlert("Success", "Appointment updated successfully!", Alert.AlertType.INFORMATION);
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        stage.close();
                    } else {
                        showAlert("Error", "No appointment was updated.", Alert.AlertType.ERROR);
                    }
                }
            }
        } catch (DateTimeParseException | NumberFormatException e) {
            showAlert("Error", "Please ensure all fields are filled correctly.", Alert.AlertType.ERROR);
        } catch (Exception e) {
            showAlert("Error", "An error occurred: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }
    
    public interface OnAppointmentUpdate {
        void onUpdate();
    }

    private OnAppointmentUpdate onAppointmentUpdateCallback;

    public void setOnAppointmentUpdateCallback(OnAppointmentUpdate callback) {
        this.onAppointmentUpdateCallback = callback;
    }

    /**
    * Updates the appointment data in the database.
    * @param appointment The appointment data to update.
    * @throws Exception If an error occurs while updating the appointment.
    */
    private void updateAppointmentInDB(Appointment appointment) throws Exception {
        Connection conn = DBConnection.connection;
        String sql = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";

        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setString(1, appointment.getTitle());
            preparedStatement.setString(2, appointment.getDescription());
            preparedStatement.setString(3, appointment.getLocation());
            preparedStatement.setString(4, appointment.getType());
            preparedStatement.setTimestamp(5, Timestamp.valueOf(appointment.getStart()));
            preparedStatement.setTimestamp(6, Timestamp.valueOf(appointment.getEnd()));
            preparedStatement.setInt(7, appointment.getCustomerID());
            preparedStatement.setInt(8, appointment.getUserID());
            preparedStatement.setInt(9, appointment.getContactID());
            preparedStatement.setInt(10, selectedAppointment.getAppointmentID());

            int result = preparedStatement.executeUpdate();
            if (result <= 0) {
                throw new Exception("Failed to update the appointment.");
            }
            
            if (onAppointmentUpdateCallback != null) {
                onAppointmentUpdateCallback.onUpdate();
            }
            
        } catch (Exception ex) {
            throw new Exception("Database error: " + ex.getMessage());
        }
    }

    /**
    * Indicates that an appointment has been updated.
    */
    public class UpdateEvent extends Event {
        public static final EventType<UpdateEvent> APPOINTMENT_UPDATED = new EventType<>(ANY, "APPOINTMENT_UPDATED");

        public UpdateEvent() {
            super(APPOINTMENT_UPDATED);
        }
    }

    /**
    * Displays an alert box with the given parameters.
    * @param title The title of the alert box.
    * @param message The message to display in the alert box.
    * @param alertType The type of alert.
    */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
    * Handles the cancel button action, which closes the window.
    */
    @FXML
    private void handleCancelButtonAction() {
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }
}