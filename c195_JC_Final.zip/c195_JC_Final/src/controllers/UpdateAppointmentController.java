// controllers/UpdateAppointmentController.java
package controllers;

import models.Appointment;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import utils.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.*;
import java.time.ZonedDateTime;
import java.sql.Timestamp;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.scene.Node;

public class UpdateAppointmentController {

    private Appointment selectedAppointment;

    @FXML
    private TextField titleField, descriptionField, locationField, typeField,
            customerIDField, userIDField, contactIDField;
    @FXML
    private DatePicker startDatePicker, endDatePicker;
    @FXML
    private ComboBox<String> startHourComboBox, startMinuteComboBox,
            endHourComboBox, endMinuteComboBox;
    @FXML
    private ComboBox<Integer> customerIDComboBox;
    @FXML
    private ComboBox<Integer> userIDComboBox;
    @FXML
    private ComboBox<Integer> contactIDComboBox;
    
    /**
    * Initializes the UI components using data from the given appointment.
    * @param appointment The appointment data to preload.
    */
    public void initialize(Appointment appointment) {
        preloadComboBoxes();
        startDatePicker.setValue(LocalDate.now());
        endDatePicker.setValue(LocalDate.now());

        this.selectedAppointment = appointment;
        preloadData();
    }
    
    /**
    * Preloads the UI components using data from the selected appointment.
    */
    private void preloadData() {
        titleField.setText(selectedAppointment.getTitle());
        descriptionField.setText(selectedAppointment.getDescription());
        locationField.setText(selectedAppointment.getLocation());
        typeField.setText(selectedAppointment.getType());
        customerIDField.setText(Integer.toString(selectedAppointment.getCustomerID()));

        // Assuming selectedAppointment.getStart() and selectedAppointment.getEnd() are in UTC
        ZonedDateTime utcStartDateTime = selectedAppointment.getStart().atZone(ZoneId.of("UTC"));
        ZonedDateTime localStartDateTime = utcStartDateTime.withZoneSameInstant(ZoneId.systemDefault());

        startDatePicker.setValue(localStartDateTime.toLocalDate());
        startHourComboBox.setValue(String.format("%02d", localStartDateTime.getHour()));
        startMinuteComboBox.setValue(String.format("%02d", localStartDateTime.getMinute()));

        ZonedDateTime utcEndDateTime = selectedAppointment.getEnd().atZone(ZoneId.of("UTC"));
        ZonedDateTime localEndDateTime = utcEndDateTime.withZoneSameInstant(ZoneId.systemDefault());

        endDatePicker.setValue(localEndDateTime.toLocalDate());
        endHourComboBox.setValue(String.format("%02d", localEndDateTime.getHour()));
        endMinuteComboBox.setValue(String.format("%02d", localEndDateTime.getMinute()));

        userIDField.setText(String.valueOf(selectedAppointment.getUserID()));
        contactIDField.setText(String.valueOf(selectedAppointment.getContactID()));
    }
    
    /**
     * Pre-loads the time ComboBoxes with relevant values.
     */
    private void preloadComboBoxes() {
        for (int i = 8; i <= 22; i++) {
            String hour = String.format("%02d", i);
            startHourComboBox.getItems().add(hour);
            endHourComboBox.getItems().add(hour);
        }
        for (int i = 0; i < 60; i += 15) {
            String minute = String.format("%02d", i);
            startMinuteComboBox.getItems().add(minute);
            endMinuteComboBox.getItems().add(minute);
        }
    }

    /**
    * Handles the save button action, which updates the selected appointment's data.
    * @param event The event that triggered this method.
    */
    @FXML
    public void handleSaveButtonAction(ActionEvent event) {
        try {
            String title = titleField.getText();
            String description = descriptionField.getText();
            String location = locationField.getText();
            String type = typeField.getText();

            LocalDate startDate = startDatePicker.getValue();
            String startHour = startHourComboBox.getSelectionModel().getSelectedItem();
            String startMinute = startMinuteComboBox.getSelectionModel().getSelectedItem();
            LocalTime startTime = LocalTime.of(Integer.parseInt(startHour), Integer.parseInt(startMinute));

            LocalDate endDate = endDatePicker.getValue();
            String endHour = endHourComboBox.getSelectionModel().getSelectedItem();
            String endMinute = endMinuteComboBox.getSelectionModel().getSelectedItem();
            LocalTime endTime = LocalTime.of(Integer.parseInt(endHour), Integer.parseInt(endMinute));

            // Convert local time to UTC before storing
            LocalDateTime localStartDateTime = LocalDateTime.of(startDate, startTime);
            ZonedDateTime zonedStartDateTime = ZonedDateTime.of(localStartDateTime, ZoneId.systemDefault());
            ZonedDateTime utcStartDateTime = zonedStartDateTime.withZoneSameInstant(ZoneId.of("UTC"));

            LocalDateTime localEndDateTime = LocalDateTime.of(endDate, endTime);
            ZonedDateTime zonedEndDateTime = ZonedDateTime.of(localEndDateTime, ZoneId.systemDefault());
            ZonedDateTime utcEndDateTime = zonedEndDateTime.withZoneSameInstant(ZoneId.of("UTC"));

            // Check against ET office hours
            ZonedDateTime etStartDateTime = utcStartDateTime.withZoneSameInstant(ZoneId.of("America/New_York"));
            if (etStartDateTime.getHour() < 9 || etStartDateTime.getHour() >= 17) {
                showAlert("Error", "The appointment time is outside of the company's business hours (in ET).", Alert.AlertType.ERROR);
                return;
            }

            selectedAppointment.setTitle(title);
            selectedAppointment.setDescription(description);
            selectedAppointment.setLocation(location);
            selectedAppointment.setType(type);
            selectedAppointment.setStart(utcStartDateTime.toLocalDateTime());
            selectedAppointment.setEnd(utcEndDateTime.toLocalDateTime());
            selectedAppointment.setCustomerID(Integer.parseInt(customerIDField.getText()));
            selectedAppointment.setUserID(Integer.parseInt(userIDField.getText()));
            selectedAppointment.setContactID(Integer.parseInt(contactIDField.getText()));

            updateAppointmentInDB(selectedAppointment);

            showAlert("Success", "Appointment updated successfully!", Alert.AlertType.INFORMATION);

            if (onAppointmentUpdateCallback != null) {
                onAppointmentUpdateCallback.onUpdate();
            }

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();

        } catch (NumberFormatException e) {
            showAlert("Error", "Please ensure all fields are filled correctly.", Alert.AlertType.ERROR);
        } catch (Exception e) {
            showAlert("Error", "An error occurred: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
    public interface OnAppointmentUpdate {
        void onUpdate();
    }

    private OnAppointmentUpdate onAppointmentUpdateCallback;

    public void setOnAppointmentUpdateCallback(OnAppointmentUpdate callback) {
        this.onAppointmentUpdateCallback = callback;
    }

    /**
    * Updates the appointment data in the database.
    * @param appointment The appointment data to update.
    * @throws Exception If an error occurs while updating the appointment.
    */
    private void updateAppointmentInDB(Appointment appointment) throws Exception {
        Connection conn = DBConnection.connection;
        String sql = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";

        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setString(1, appointment.getTitle());
            preparedStatement.setString(2, appointment.getDescription());
            preparedStatement.setString(3, appointment.getLocation());
            preparedStatement.setString(4, appointment.getType());
            preparedStatement.setTimestamp(5, Timestamp.valueOf(appointment.getStart()));
            preparedStatement.setTimestamp(6, Timestamp.valueOf(appointment.getEnd()));
            preparedStatement.setInt(7, appointment.getCustomerID());
            preparedStatement.setInt(8, appointment.getUserID());
            preparedStatement.setInt(9, appointment.getContactID());
            preparedStatement.setInt(10, selectedAppointment.getAppointmentID());

            int result = preparedStatement.executeUpdate();
            if (result <= 0) {
                throw new Exception("Failed to update the appointment.");
            }
            
            if (onAppointmentUpdateCallback != null) {
                onAppointmentUpdateCallback.onUpdate();
            }
            
        } catch (Exception ex) {
            throw new Exception("Database error: " + ex.getMessage());
        }
    }

    /**
    * Represents a custom event which indicates that an appointment has been updated.
    */
    public class UpdateEvent extends Event {
        public static final EventType<UpdateEvent> APPOINTMENT_UPDATED = new EventType<>(ANY, "APPOINTMENT_UPDATED");

        public UpdateEvent() {
            super(APPOINTMENT_UPDATED);
        }
    }

    /**
    * Displays an alert box with the given parameters.
    * @param title The title of the alert box.
    * @param message The message to display in the alert box.
    * @param alertType The type of alert.
    */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
    * Handles the cancel button action, which closes the window.
    */
    @FXML
    private void handleCancelButtonAction() {
        Stage stage = (Stage) titleField.getScene().getWindow();
        stage.close();
    }
}
