// controllers/UpdateCustomerController.java

package controllers;

import models.Customer;
import models.Division;
import models.User;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import utils.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import javafx.scene.control.ListCell;
import models.Country;

public class UpdateCustomerController {
    @FXML
    private TextField customerIDField;
    @FXML
    private TextField customerNameField, addressField, postalCodeField, phoneField;
    @FXML
    private ComboBox<Division> divisionIDComboBox;
    @FXML
    private ComboBox<User> userComboBox;
    @FXML
    private Customer customerToUpdate;
    @FXML
    private DashboardController dashboardController;
    @FXML
    private ComboBox<Country> countryComboBox;

    /**
    * Initializes the UI components by populating the user, country and division comboboxes.
    */
    @FXML
    public void initialize() {
        populateUsers();
        //populateDivisions();
        populateCountries();
            
         countryComboBox.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                populateDivisionsBasedOnCountry(newValue);
            } else {
                divisionIDComboBox.getItems().clear();
                divisionIDComboBox.setPromptText("Select a Country first");
            }
        });
    }

    private void populateCountries() {
        String SQL = "SELECT * FROM countries";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            java.sql.ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Country country = new Country();
                country.setCountryID(rs.getInt("Country_ID"));
                country.setCountryName(rs.getString("Country"));

                countryComboBox.getItems().add(country);
            }

            // Display the country name in the ComboBox
            countryComboBox.setCellFactory((comboBox) -> {
                return new ListCell<Country>() {
                    @Override
                    protected void updateItem(Country country, boolean empty) {
                        super.updateItem(country, empty);
                        if (country == null || empty) {
                            setText(null);
                        } else {
                            setText(country.getCountryName());
                        }
                    }
                };
            });
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void populateDivisionsBasedOnCountry(Country selectedCountry) {
        divisionIDComboBox.getItems().clear();

        String countryName = selectedCountry.getCountryName();

        int country_ID = selectedCountry.getCountryID();

        String SQL = "SELECT * FROM first_level_divisions WHERE Country_ID = ?";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setInt(1, country_ID);
            java.sql.ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Division division = new Division();
                division.setDivisionID(rs.getInt("Division_ID"));
                division.setDivisionName(rs.getString("Division"));

                divisionIDComboBox.getItems().add(division);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
    * Sets the dashboard controller.
    * @param dashboardController The dashboard controller to set.
    */
    public void setDashboardController(DashboardController dashboardController) {
        this.dashboardController = dashboardController;
    }  

    /**
    * Populates the user ComboBox by fetching user details from the database.
    */
    private void populateUsers() {
        String SQL = "SELECT * FROM users";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            java.sql.ResultSet rs = (java.sql.ResultSet) stmt.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setUserID(rs.getInt("User_ID"));
                user.setUserName(rs.getString("User_Name"));

                userComboBox.getItems().add(user);
            }

            // Display the user's name in the ComboBox
            userComboBox.setCellFactory((comboBox) -> {
                return new ListCell<User>() {
                    @Override
                    protected void updateItem(User user, boolean empty) {
                        super.updateItem(user, empty);
                        if (user == null || empty) {
                            setText(null);
                        } else {
                            setText(user.getUserName());
                        }
                    }
                };
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
    * Populates the division ComboBox by fetching division details from the database.
    */
    private void populateDivisions() {
        String SQL = "SELECT * FROM first_level_divisions";
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            java.sql.ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Division division = new Division();
                division.setDivisionID(rs.getInt("Division_ID"));
                division.setDivisionName(rs.getString("Division"));

                divisionIDComboBox.getItems().add(division);
            }

            divisionIDComboBox.setCellFactory((comboBox) -> {
                return new ListCell<Division>() {
                    @Override
                    protected void updateItem(Division division, boolean empty) {
                        super.updateItem(division, empty);
                        if (division == null || empty) {
                            setText(null);
                        } else {
                            setText(division.getDivisionName());
                        }
                    }
                };
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Country getCountryByCustomer(Customer customer) {
        String SQL = "SELECT client_schedule.countries.Country_ID, client_schedule.countries.Country " +
                     "FROM client_schedule.customers " +
                     "INNER JOIN client_schedule.first_level_divisions " +
                     "ON client_schedule.customers.Division_ID = client_schedule.first_level_divisions.Division_ID " +
                     "INNER JOIN client_schedule.countries " +
                     "ON client_schedule.first_level_divisions.Country_ID = client_schedule.countries.Country_ID " +
                     "WHERE client_schedule.customers.Customer_ID = ?";

        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setInt(1, customer.getCustomerID());
            java.sql.ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Country country = new Country();
                country.setCountryID(rs.getInt("Country_ID"));
                country.setCountryName(rs.getString("Country"));
                return country;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
    * Sets the UI components with the details of a given customer.
    * @param customer The customer whose details are to be displayed.
    */
    public void setCustomer(Customer customer) {
        this.customerToUpdate = customer;

        customerIDField.setText(String.valueOf(customer.getCustomerID()));
        customerNameField.setText(customer.getCustomerName());
        addressField.setText(customer.getAddress());
        postalCodeField.setText(customer.getPostalCode());
        phoneField.setText(customer.getPhone());

        // Setting the User
        User selectedUser = userComboBox.getItems().stream()
            .filter(user -> user.getUserName().equals(customer.getCreatedBy()))
            .findFirst().orElse(null);

        if (selectedUser != null) {
            userComboBox.getSelectionModel().select(selectedUser);
        }

        Country customerCountry = getCountryByCustomer(customer);
        if (customerCountry != null) {
            countryComboBox.getSelectionModel().select(customerCountry);
            populateDivisionsBasedOnCountry(customerCountry);
        }

        Division selectedDivision = divisionIDComboBox.getItems().stream()
            .filter(division -> division.getDivisionID() == customer.getDivisionID())
            .findFirst().orElse(null);

        if (selectedDivision != null) {
            divisionIDComboBox.getSelectionModel().select(selectedDivision);
        }
    }

    // Helper method to determine the country based on the division ID
    private int getCountryIDByDivisionID(int divisionID) {
        String SQL = "SELECT Country_ID FROM first_level_divisions WHERE Division_ID = ?";
        int countryID = -1;
        try {
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);
            stmt.setInt(1, divisionID);
            java.sql.ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                countryID = rs.getInt("Country_ID");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return countryID;
    }
    
    public interface OnCustomerUpdate {
        void onUpdate();
    }

    private OnCustomerUpdate onCustomerUpdateCallback;

    public void setOnCustomerUpdateCallback(OnCustomerUpdate callback) {
        this.onCustomerUpdateCallback = callback;
    }

    /**
    * Handles the save button action, which updates the selected customer's details in the database.
    */
    @FXML
    private void handleSaveButtonAction() {
        try {
            String SQL = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Create_Date = ?, Created_By = ?, Last_Update = ?, Last_Updated_By = ?, Division_ID = ? WHERE Customer_ID = ?";
            Connection conn = DBConnection.connection;
            PreparedStatement stmt = conn.prepareStatement(SQL);

            LocalDateTime now = LocalDateTime.now();

            stmt.setString(1, customerNameField.getText());
            stmt.setString(2, addressField.getText());
            stmt.setString(3, postalCodeField.getText());
            stmt.setString(4, phoneField.getText());
            stmt.setTimestamp(5, Timestamp.valueOf(now));
            stmt.setString(6, userComboBox.getSelectionModel().getSelectedItem().getUserName());
            stmt.setTimestamp(7, Timestamp.valueOf(now));
            stmt.setString(8, userComboBox.getSelectionModel().getSelectedItem().getUserName());
            //stmt.setInt(8, countryComboBox.getSelectionModel().getSelectedItem().getCountryID());
            stmt.setInt(9, divisionIDComboBox.getSelectionModel().getSelectedItem().getDivisionID());
            stmt.setInt(10, customerToUpdate.getCustomerID());

            stmt.executeUpdate();
            
            if (onCustomerUpdateCallback != null) {
                onCustomerUpdateCallback.onUpdate();
            }

            Stage stage = (Stage) customerNameField.getScene().getWindow();
            stage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
    * Handles the cancel button action, which closes the window.
    */
    @FXML
    private void handleCancelButtonAction() {
        Stage stage = (Stage) customerNameField.getScene().getWindow();
        stage.close();
    }
}
