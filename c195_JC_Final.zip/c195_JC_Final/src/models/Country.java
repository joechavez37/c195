// models/Country.java

package models;

public class Country {
    private int Country_ID;
    private String Country_Name;

    // Default constructor
    public Country() {}

    // Parameterized constructor
    public Country(int Country_ID, String Country_Name) {
        this.Country_ID = Country_ID;
        this.Country_Name = Country_Name;
    }

    // Getters and Setters
    public int getCountryID() {
        return Country_ID;
    }

    public void setCountryID(int countryID) {
        this.Country_ID = countryID;
    }

    public String getCountryName() {
        return Country_Name;
    }

    public void setCountryName(String countryName) {
        this.Country_Name = countryName;
    }

    @Override
    public String toString() {
        return Country_Name;
    }
}
