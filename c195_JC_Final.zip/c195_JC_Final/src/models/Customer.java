// models/Customer.java
package models;

public class Customer {
    private int customerID;
    private String customerName;
    private String address;
    private String postalCode;
    private String phone;
    private String Created_By;
    private int divisionID;

    public Customer(int customerID, String customerName, String address, String postalCode, 
                String phone, String Created_By, int divisionID) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.address = address;
        this.postalCode = postalCode;
        this.phone = phone;
        this.Created_By = Created_By;
        this.divisionID = divisionID;
    }

    // Getters and setters
    public int getCustomerID() {
        return customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getAddress() {
        return address;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getPhone() {
        return phone;
    }
    
    public String getCreatedBy() {
        return Created_By;
    }

    public int getDivisionID() {
        return divisionID;
    }

    // Setters
    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void createdBy(String Created_By) {
        this.Created_By = Created_By;
    }
    
    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }
}
