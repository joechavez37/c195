// models/Division.java

package models;

import java.time.LocalDateTime;

public class Division {

    private int Division_ID;
    private String Division;
    private LocalDateTime Create_Date;
    private String Created_By;
    private LocalDateTime Last_Update;
    private String Last_Updated_By;
    private int Country_ID;

    // Default constructor
    public Division() {}

    // Parameterized constructor
    public Division(int Division_ID, String Division, LocalDateTime Create_Date, 
                    String Created_By, LocalDateTime Last_Update, String Last_Updated_By, int Country_ID) {
        this.Division_ID = Division_ID;
        this.Division = Division;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;
        this.Country_ID = Country_ID;
    }

    // Getters and Setters

    public int getDivisionID() {
        return Division_ID;
    }

    public void setDivisionID(int divisionID) {
        this.Division_ID = divisionID;
    }

    public String getDivisionName() {
        return Division;
    }

    public void setDivisionName(String Division) {
        this.Division = Division;
    }

    public LocalDateTime getCreateDate() {
        return Create_Date;
    }

    public void setCreateDate(LocalDateTime Create_Date) {
        this.Create_Date = Create_Date;
    }

    public String getCreatedBy() {
        return Created_By;
    }

    public void setCreatedBy(String Created_By) {
        this.Created_By = Created_By;
    }

    public LocalDateTime getLastUpdate() {
        return Last_Update;
    }

    public void setLastUpdate(LocalDateTime Last_Update) {
        this.Last_Update = Last_Update;
    }

    public String getLastUpdatedBy() {
        return Last_Updated_By;
    }

    public void setLastUpdatedBy(String Last_Updated_By) {
        this.Last_Updated_By = Last_Updated_By;
    }

    public int getCountryID() {
        return Country_ID;
    }

    public void setCountryID(int Country_ID) {
        this.Country_ID = Country_ID;
    }

    @Override
    public String toString() {
        return Division;
    }
}
