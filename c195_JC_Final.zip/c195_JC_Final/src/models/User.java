// models/User.java

package models;

public class User {

    private int User_ID;
    private String User_Name;
    private String Passwod;

    // Default constructor
    public User() {}

    // Parameterized constructor
    public User(int User_ID, String User_Name, String Passwod) {
        this.User_ID = User_ID;
        this.User_Name = User_Name;
        this.Passwod = Passwod;
    }

    // Getters and Setters

    public int getUserID() {
        return User_ID;
    }

    public void setUserID(int User_ID) {
        this.User_ID = User_ID;
    }

    public String getUserName() {
        return User_Name;
    }

    public void setUserName(String User_Name) {
        this.User_Name = User_Name;
    }

    public String getPassword() {
        return Passwod;
    }

    public void setPassword(String Passwod) {
        this.Passwod = Passwod;
    }

    @Override
    public String toString() {
        return User_Name;
    }
}
