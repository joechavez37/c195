/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

/**
 *
 * @author joech
 */

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class LoginActivityLogger {

    private static final String FILE_PATH = "login_activity.txt";

    public static void logActivity(String username, boolean success) {
        String status = success ? "SUCCESSFUL" : "FAILED";
        String logMessage = String.format("USER: %s | DATE & TIME: %s | STATUS: %s\n", 
                                           username, 
                                           LocalDateTime.now().toString(), 
                                           status);
        
        try (FileWriter fw = new FileWriter(FILE_PATH, true)) {
            fw.write(logMessage);
        } catch (IOException e) {
            System.err.println("Error logging user activity: " + e.getMessage());
        }
    }
}
