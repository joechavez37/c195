// Utility class for session information
package utils;

import java.time.ZoneId;

public class SessionInfo {
    private static ZoneId userTimeZone = ZoneId.systemDefault();

    public static ZoneId getUserTimeZone() {
        return userTimeZone;
    }

    public static void setUserTimeZone(ZoneId zoneId) {
        userTimeZone = zoneId;
    }
}
