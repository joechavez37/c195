package utils;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class TimeUtil {

    // Formatter for database and display purposes
    private static final DateTimeFormatter DB_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter DISPLAY_FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");

    // Convert local time to UTC for database storage
    public static String toUTCString(ZonedDateTime localDateTime) {
        ZonedDateTime utcTime = localDateTime.withZoneSameInstant(ZoneId.of("UTC"));
        return DB_FORMATTER.format(utcTime);
    }

    // Convert from UTC (database) to local time for display
    public static String fromUTCString(String utcTimeString, ZoneId userZoneId) {
        ZonedDateTime utcDateTime = ZonedDateTime.parse(utcTimeString, DB_FORMATTER).withZoneSameInstant(userZoneId);
        return DISPLAY_FORMATTER.format(utcDateTime);
    }

    // Get current time in user's timezone as a formatted string
    public static String nowInUserTimeZone(ZoneId userZoneId) {
        ZonedDateTime userNow = ZonedDateTime.now(userZoneId);
        return DISPLAY_FORMATTER.format(userNow);
    }
    
    /**
     * Converts a LocalDateTime from a given time zone to UTC.
     * @param localDateTime The local date and time to convert.
     * @param fromZoneId The ID of the local time zone (e.g., "America/New_York" for EST/EDT).
     * @return The LocalDateTime in UTC.
     */
    public static LocalDateTime convertLocalToUtc(LocalDateTime localDateTime, String fromZoneId) {
        ZoneId zoneId;
        try {
            zoneId = ZoneId.of(fromZoneId);
        } catch (DateTimeException e) {
            throw new IllegalArgumentException("Invalid time zone ID: " + fromZoneId, e);
        }
        ZonedDateTime zonedDateTime = localDateTime.atZone(zoneId);
        // Convert to UTC and return as LocalDateTime
        return zonedDateTime.withZoneSameInstant(ZoneId.of("UTC")).toLocalDateTime();
    }
    
    /**
     * Combines LocalDate and time (hour and minute) into a LocalDateTime, with hour and minute as strings.
     *
     * @param date    The LocalDate.
     * @param hourStr The hour of the day as a String.
     * @param minuteStr The minute of the hour as a String.
     * @return A LocalDateTime representing the combined date and time.
     */
    public static LocalDateTime combineLocalDateAndTime(LocalDate date, String hourStr, String minuteStr) {
        // Parse hour and minute strings to integers
        int hour = Integer.parseInt(hourStr);
        int minute = Integer.parseInt(minuteStr);

        // Validate parsed hour and minute
        if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
            throw new IllegalArgumentException("Hour or minute out of range");
        }

        LocalTime time = LocalTime.of(hour, minute);
        return LocalDateTime.of(date, time);
    }
    
     /* Converts a LocalDateTime from UTC to a specified time zone.
     * @param utcDateTime The UTC LocalDateTime to convert.
     * @param targetZoneId The target ZoneId to convert the LocalDateTime to.
     * @return The LocalDateTime converted to the target time zone.
     */
    public static LocalDateTime convertUtcToLocal(LocalDateTime utcDateTime, ZoneId targetZoneId) {
        // Convert the LocalDateTime from UTC to the target time zone
        ZonedDateTime utcZonedDateTime = utcDateTime.atZone(ZoneOffset.UTC);
        ZonedDateTime targetZonedDateTime = utcZonedDateTime.withZoneSameInstant(targetZoneId);
        return targetZonedDateTime.toLocalDateTime();
    }
}

