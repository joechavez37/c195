package utils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class TimeUtil {

    private static final ZoneId UTC_ZONE_ID = ZoneId.of("UTC");
    
    /**
     * Converts a LocalDateTime from UTC to a specified time zone's local date and time.
     */
    public static LocalDateTime convertUtcToLocal(LocalDateTime utcDateTime, ZoneId targetZoneId) {
        ZonedDateTime zonedUtcDateTime = utcDateTime.atZone(UTC_ZONE_ID);
        ZonedDateTime zonedTargetDateTime = zonedUtcDateTime.withZoneSameInstant(targetZoneId);
        return zonedTargetDateTime.toLocalDateTime();
    }

    /**
     * Converts a LocalDateTime from a specified time zone's local date and time to UTC.
     */
    public static LocalDateTime convertLocalToUtc(LocalDateTime localDateTime, ZoneId sourceZoneId) {
        ZonedDateTime zonedSourceDateTime = localDateTime.atZone(sourceZoneId);
        ZonedDateTime zonedUtcDateTime = zonedSourceDateTime.withZoneSameInstant(UTC_ZONE_ID);
        return zonedUtcDateTime.toLocalDateTime();
    }
    
    /**
     * Formats a LocalDateTime to a string using the specified pattern.
     */
    public static String formatDateTime(LocalDateTime dateTime, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return dateTime.format(formatter);
    }
}
