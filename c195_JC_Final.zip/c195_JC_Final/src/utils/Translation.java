/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

/**
 *
 * @author joech
 */
public class Translation {
    
    enum Translations {
        USERNAME_EN("Username"),
        USERNAME_FR("Nom d'utilisateur"),
        PASSWORD_EN("Password"),
        PASSWORD_FR("Mot de passe"),
        LOGIN_EN("Login"),
        LOGIN_FR("Connexion"),
        LOGIN_ERROR_EN("Invalid username or password!"),
        LOGIN_ERROR_FR("Nom d'utilisateur ou mot de passe invalide!");

        private final String text;

        Translations(String text) {
            this.text = text;
        }

        public String getText() {
            return text;
        }
    }
    
}
